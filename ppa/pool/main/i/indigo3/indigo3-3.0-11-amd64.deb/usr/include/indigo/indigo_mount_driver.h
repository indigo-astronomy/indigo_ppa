// Copyright (c) 2016-2025 CloudMakers, s. r. o.
// All rights reserved.
//
// You can use this software under the terms of 'INDIGO Astronomy
// open-source license' (see LICENSE.md).
//
// THIS SOFTWARE IS PROVIDED BY THE AUTHORS 'AS IS' AND ANY EXPRESS
// OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
// GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
// WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

// version history
// 2.0 by Peter Polakovic <peter.polakovic@cloudmakers.eu>

/** INDIGO Mount Driver base
 \file indigo_mount_driver.h
 */

#ifndef indigo_mount_h
#define indigo_mount_h

#include <indigo/indigo_bus.h>
#include <indigo/indigo_driver.h>

#if defined(INDIGO_WINDOWS)
#if defined(INDIGO_WINDOWS_DLL)
#define INDIGO_EXTERN __declspec(dllexport)
#else
#define INDIGO_EXTERN __declspec(dllimport)
#endif
#else
#define INDIGO_EXTERN extern
#endif

#ifdef __cplusplus
extern "C" {
#endif

/** Main mount group name string.
 */
#define MOUNT_MAIN_GROUP															"Mount"

/** Mount alignment group name string.
 */
#define MOUNT_ALIGNMENT_GROUP													"Alignment"

/** Site group name string.
 */
#define MOUNT_SITE_GROUP															SITE_GROUP

/** Advanced group name string.
 */
#define MOUNT_ADVANCED_GROUP           								ADVANCED_GROUP

/** Device context pointer.
 */
#define MOUNT_CONTEXT																	((indigo_mount_context *)device->device_context)

//-------------------------------------------
/** MOUNT_GEOGRAPHIC_COORDINATES property pointer, property is mandatory, property change request should be fully handled by device driver.
 */
#define MOUNT_GEOGRAPHIC_COORDINATES_PROPERTY					(MOUNT_CONTEXT->mount_geographic_coordinates_property)

/** MOUNT_GEOGRAPHIC_COORDINATES.LATITUDE property item pointer.
 */
#define MOUNT_GEOGRAPHIC_COORDINATES_LATITUDE_ITEM		(MOUNT_GEOGRAPHIC_COORDINATES_PROPERTY->items+0)

/** MOUNT_GEOGRAPHIC_COORDINATES.LONGITUDE property item pointer.
 */
#define MOUNT_GEOGRAPHIC_COORDINATES_LONGITUDE_ITEM		(MOUNT_GEOGRAPHIC_COORDINATES_PROPERTY->items+1)

/** MOUNT_GEOGRAPHIC_COORDINATES.ELEVATION property item pointer.
 */
#define MOUNT_GEOGRAPHIC_COORDINATES_ELEVATION_ITEM		(MOUNT_GEOGRAPHIC_COORDINATES_PROPERTY->items+2)

//---------------------------------------------
/** MOUNT_LST_TIME property pointer, property is optional, property change request should be fully handled by device driver.
 */
#define MOUNT_LST_TIME_PROPERTY												(MOUNT_CONTEXT->mount_lst_time_property)

/** MOUNT_TIME.TIME property item pointer.
 */
#define MOUNT_LST_TIME_ITEM														(MOUNT_LST_TIME_PROPERTY->items+0)

//---------------------------------------------
/** MOUNT_INFO property pointer, property is optional, property change request should be fully handled by device driver.
 */
#define MOUNT_INFO_PROPERTY														(MOUNT_CONTEXT->mount_info_property)

/** MOUNT_INFO.VENDOR property item pointer.
 */
#define MOUNT_INFO_VENDOR_ITEM												(MOUNT_INFO_PROPERTY->items+0)

/** MOUNT_INFO.MODEL property item pointer.
 */
#define MOUNT_INFO_MODEL_ITEM													(MOUNT_INFO_PROPERTY->items+1)

/** MOUNT_INFO.FIRMWARE property item pointer.
 */
#define MOUNT_INFO_FIRMWARE_ITEM											(MOUNT_INFO_PROPERTY->items+2)


//---------------------------------------------
/** MOUNT_UTC_TIME property pointer, property is optional, property change request should be fully handled by the device driver.
 */
#define MOUNT_UTC_TIME_PROPERTY												(MOUNT_CONTEXT->mount_utc_time_property)

/** MOUNT_UTC_TIME.UTC property item pointer.
 */
#define MOUNT_UTC_ITEM															(MOUNT_UTC_TIME_PROPERTY->items+0)

/** MOUNT_UTC_TIME.OFFSET property item pointer.
 */
#define MOUNT_UTC_OFFSET_ITEM													(MOUNT_UTC_TIME_PROPERTY->items+1)

//----------------------------------------------
/** MOUNT_SET_HOST_TIME property pointer, property is optional, property change request should be fully handled by the device driver.
 */
#define MOUNT_SET_HOST_TIME_PROPERTY									(MOUNT_CONTEXT->mount_set_host_time_property)

/** MOUNT_SET_HOST_TIME.SET property item pointer.
 */
#define MOUNT_SET_HOST_TIME_ITEM											(MOUNT_SET_HOST_TIME_PROPERTY->items+0)

//----------------------------------------------
/** MOUNT_PARK_SET property pointer, property is optional, property change request should be fully handled by indigo_mount_change_property.
 */
#define MOUNT_PARK_SET_PROPERTY												(MOUNT_CONTEXT->mount_set_park_property)

/** MOUNT_PARK_SET.CURRENT property item pointer.
 */
#define MOUNT_PARK_SET_CURRENT_ITEM										(MOUNT_PARK_SET_PROPERTY->items+0)

/** MOUNT_PARK_SET.DEFAULT property item pointer.
 */
#define MOUNT_PARK_SET_DEFAULT_ITEM										(MOUNT_PARK_SET_PROPERTY->items+1)

//----------------------------------------------
/** MOUNT_PARK_POSITION property pointer, property is optional, property change request should be fully handled by indigo_mount_change_property.
*/
#define MOUNT_PARK_POSITION_PROPERTY									(MOUNT_CONTEXT->mount_park_position_property)

/** MOUNT_PARK_POSITION.RA property item pointer.
*/
#define MOUNT_PARK_POSITION_HA_ITEM										(MOUNT_PARK_POSITION_PROPERTY->items+0)

/** MOUNT_PARK_POSITION.DEC property item pointer.
*/
#define MOUNT_PARK_POSITION_DEC_ITEM									(MOUNT_PARK_POSITION_PROPERTY->items+1)

//----------------------------------------------
/** MOUNT_PARK property pointer, property is optional, property change request should be fully handled by device driver.
*/
#define MOUNT_PARK_PROPERTY														(MOUNT_CONTEXT->mount_park_property)

/** MOUNT_PARK.PARKED property item pointer.
*/
#define MOUNT_PARK_PARKED_ITEM												(MOUNT_PARK_PROPERTY->items+0)

/** MOUNT_PARK.UNPARKED property item pointer.
*/
#define MOUNT_PARK_UNPARKED_ITEM											(MOUNT_PARK_PROPERTY->items+1)

//----------------------------------------------
/** MOUNT_HOME_SET property pointer, property is optional, property change request should be fully handled by indigo_mount_change_property.
*/
#define MOUNT_HOME_SET_PROPERTY												(MOUNT_CONTEXT->mount_set_home_property)

/** MOUNT_HOME_SET.CURRENT property item pointer.
 */
#define MOUNT_HOME_SET_CURRENT_ITEM										(MOUNT_HOME_SET_PROPERTY->items+0)

/** MOUNT_HOME_SET.DEFAULT property item pointer.
*/
#define MOUNT_HOME_SET_DEFAULT_ITEM										(MOUNT_HOME_SET_PROPERTY->items+1)

//----------------------------------------------
/** MOUNT_HOME_POSITION property pointer, property is optional, property change request should be fully handled by indigo_mount_change_property.
*/
#define MOUNT_HOME_POSITION_PROPERTY									(MOUNT_CONTEXT->mount_home_position_property)

/** MOUNT_HOME_POSITION.RA property item pointer.
*/
#define MOUNT_HOME_POSITION_HA_ITEM										(MOUNT_HOME_POSITION_PROPERTY->items+0)

/** MOUNT_HOME_POSITION.DEC property item pointer.
*/
#define MOUNT_HOME_POSITION_DEC_ITEM									(MOUNT_HOME_POSITION_PROPERTY->items+1)

//----------------------------------------------
/** MOUNT_HOME property pointer, property is optional, property change request should be fully handled by device driver.
*/
#define MOUNT_HOME_PROPERTY														(MOUNT_CONTEXT->mount_home_property)

/** MOUNT_HOME.HOME property item pointer.
*/
#define MOUNT_HOME_ITEM												        (MOUNT_HOME_PROPERTY->items+0)

/** MOUNT_HOME.AWAY property item pointer.
*/
#define MOUNT_AWAY_ITEM												        (MOUNT_HOME_PROPERTY->items+1)

/** MOUNT_HOME.SEARCH property item pointer.
*/
#define MOUNT_HOME_SEARCH_ITEM												(MOUNT_HOME_PROPERTY->items+2)

//----------------------------------------------
/** MOUNT_ON_COORDINATES_SET property pointer, property is mandatory, property change request is handled by indigo_mount_change_property.
 */
#define MOUNT_ON_COORDINATES_SET_PROPERTY							(MOUNT_CONTEXT->mount_on_coordinates_set_property)

/** MOUNT_ON_COORDINATES_SET.TRACK property item pointer.
 */
#define MOUNT_ON_COORDINATES_SET_TRACK_ITEM						(MOUNT_ON_COORDINATES_SET_PROPERTY->items+0)

/** MOUNT_ON_COORDINATES_SET.SYNC property item pointer.
 */
#define MOUNT_ON_COORDINATES_SET_SYNC_ITEM						(MOUNT_ON_COORDINATES_SET_PROPERTY->items+1)

/** MOUNT_ON_COORDINATES_SET.SLEW property item pointer.
 */
#define MOUNT_ON_COORDINATES_SET_SLEW_ITEM						(MOUNT_ON_COORDINATES_SET_PROPERTY->items+2)

//---------------------------------------------
/** MOUNT_SLEW_RATE property pointer, property is mandatory, property change request is handled by indigo_mount_change_property.
 */
#define MOUNT_SLEW_RATE_PROPERTY											(MOUNT_CONTEXT->mount_slew_rate_property)

/** MOUNT_SLEW_RATE.GUIDE property item pointer.
 */
#define MOUNT_SLEW_RATE_GUIDE_ITEM										(MOUNT_SLEW_RATE_PROPERTY->items+0)

/** MOUNT_SLEW_RATE.CENTERING property item pointer.
 */
#define MOUNT_SLEW_RATE_CENTERING_ITEM								(MOUNT_SLEW_RATE_PROPERTY->items+1)

/** MOUNT_SLEW_RATE.FIND property item pointer.
 */
#define MOUNT_SLEW_RATE_FIND_ITEM											(MOUNT_SLEW_RATE_PROPERTY->items+2)

/** MOUNT_SLEW_RATE.MAX property item pointer.
 */
#define MOUNT_SLEW_RATE_MAX_ITEM											(MOUNT_SLEW_RATE_PROPERTY->items+3)

//----------------------------------------------
/** MOUNT_MOTION_NS property pointer, property is mandatory, property change request is handled by indigo_mount_change_property.
 */
#define MOUNT_MOTION_DEC_PROPERTY											(MOUNT_CONTEXT->mount_motion_dec_property)

/** MOUNT_MOTION_NS.NORTH property item pointer.
 */
#define  MOUNT_MOTION_NORTH_ITEM											(MOUNT_MOTION_DEC_PROPERTY->items+0)

/** MOUNT_MOTION_NS.SOUTH property item pointer.
 */
#define  MOUNT_MOTION_SOUTH_ITEM						          (MOUNT_MOTION_DEC_PROPERTY->items+1)

//----------------------------------------------
/** MOUNT_MOTION_WE property pointer, property is mandatory, property change request is handled by indigo_mount_change_property.
 */
#define MOUNT_MOTION_RA_PROPERTY											(MOUNT_CONTEXT->mount_motion_ra_property)

/** MOUNT_MOTION_WE.WEST property item pointer.
 */
#define  MOUNT_MOTION_WEST_ITEM												(MOUNT_MOTION_RA_PROPERTY->items+0)

/** MOUNT_MOTION_WE.EAST property item pointer.
 */
#define  MOUNT_MOTION_EAST_ITEM						            (MOUNT_MOTION_RA_PROPERTY->items+1)

//-----------------------------------------------
/** MOUNT_TRACK_RATE property pointer, property is mandatory, property change request is handled by indigo_mount_change_property.
 */
#define MOUNT_TRACK_RATE_PROPERTY											(MOUNT_CONTEXT->mount_track_rate_property)

/** MOUNT_TRACK_RATE.SIDEREAL property item pointer.
 */
#define MOUNT_TRACK_RATE_SIDEREAL_ITEM								(MOUNT_TRACK_RATE_PROPERTY->items+0)

/** MOUNT_TRACK_RATE.SOLAR property item pointer.
 */
#define MOUNT_TRACK_RATE_SOLAR_ITEM										(MOUNT_TRACK_RATE_PROPERTY->items+1)

/** MOUNT_TRACK_RATE.LINAR property item pointer.
 */
#define MOUNT_TRACK_RATE_LUNAR_ITEM										(MOUNT_TRACK_RATE_PROPERTY->items+2)

/** MOUNT_TRACK_RATE.KING property item pointer.
 */
#define MOUNT_TRACK_RATE_KING_ITEM										(MOUNT_TRACK_RATE_PROPERTY->items+3)

/** MOUNT_TRACK_RATE.CUSTOM property item pointer.
 */
#define MOUNT_TRACK_RATE_CUSTOM_ITEM									(MOUNT_TRACK_RATE_PROPERTY->items+4)

//-----------------------------------------------
/** MOUNT_TRACKING property pointer, property is mandatory, property change request is handled by indigo_mount_change_property.
 */
#define MOUNT_TRACKING_PROPERTY												(MOUNT_CONTEXT->mount_tracking_property)

/** MOUNT_TRACKING.ON property item pointer.
 */
#define MOUNT_TRACKING_ON_ITEM												(MOUNT_TRACKING_PROPERTY->items+0)

/** MOUNT_TRACKING.OFF property item pointer.
 */
#define MOUNT_TRACKING_OFF_ITEM												(MOUNT_TRACKING_PROPERTY->items+1)

//-----------------------------------------------
/** MOUNT_CUSTOM_TRACKING_RATE property pointer, property is optional, property change request is handled by indigo_mount_change_property.
 */
#define MOUNT_CUSTOM_TRACKING_RATE_PROPERTY						(MOUNT_CONTEXT->mount_custom_tracking_rate_property)

/** MOUNT_CUSTOM_TRACKING_RATE.RATE property item pointer.
 */
#define MOUNT_CUSTOM_TRACKING_RATE_ITEM								(MOUNT_CUSTOM_TRACKING_RATE_PROPERTY->items+0)

//-----------------------------------------------
/** MOUNT_GUIDE_RATE property pointer, property is mandatory, property change request is handled by indigo_mount_change_property.
 */
#define MOUNT_GUIDE_RATE_PROPERTY											(MOUNT_CONTEXT->mount_guide_rate_property)

/** MOUNT_GUIDE_RATE.RA property item pointer.
 */
#define MOUNT_GUIDE_RATE_RA_ITEM											(MOUNT_GUIDE_RATE_PROPERTY->items+0)

/** MOUNT_GUIDE_RATE.DEC property item pointer.
 */
#define MOUNT_GUIDE_RATE_DEC_ITEM											(MOUNT_GUIDE_RATE_PROPERTY->items+1)

//-----------------------------------------------
/** MOUNT_EQUATORIAL_COORDINATES property pointer, property is mandatory, property change request should be fully handled by device driver.
 */
#define MOUNT_EQUATORIAL_COORDINATES_PROPERTY					(MOUNT_CONTEXT->mount_equatorial_coordinates_property)

/** MOUNT_EQUATORIAL_COORDINATES.RA property item pointer.
 */
#define MOUNT_EQUATORIAL_COORDINATES_RA_ITEM					(MOUNT_EQUATORIAL_COORDINATES_PROPERTY->items+0)

/** MOUNT_EQUATORIAL_COORDINATES.DEC property item pointer.
 */
#define MOUNT_EQUATORIAL_COORDINATES_DEC_ITEM					(MOUNT_EQUATORIAL_COORDINATES_PROPERTY->items+1)

//-----------------------------------------------
/** MOUNT_HORIZONTAL_COORDINATES property pointer, property is optional, property change request should be fully handled by device driver.
 */
#define MOUNT_HORIZONTAL_COORDINATES_PROPERTY					(MOUNT_CONTEXT->mount_horizontal_coordinates_property)

/** MOUNT_HORIZONTAL_COORDINATES.AZ property item pointer.
 */
#define MOUNT_HORIZONTAL_COORDINATES_AZ_ITEM					(MOUNT_HORIZONTAL_COORDINATES_PROPERTY->items+0)

/** MOUNT_HORIZONTAL_COORDINATES.ALT property item pointer.
 */
#define MOUNT_HORIZONTAL_COORDINATES_ALT_ITEM					(MOUNT_HORIZONTAL_COORDINATES_PROPERTY->items+1)

//------------------------------------------------
/** MOUNT_ABORT_MOTION property pointer, property is mandatory, property change request should be fully handled by focuser driver
 */
#define MOUNT_ABORT_MOTION_PROPERTY										(MOUNT_CONTEXT->mount_abort_motion_property)

/** FOCUSER_ABORT_MOTION.ABORT_MOTION property item pointer.
 */
#define MOUNT_ABORT_MOTION_ITEM												(MOUNT_ABORT_MOTION_PROPERTY->items+0)

//------------------------------------------------
/** MOUNT_ALIGNMENT_MODE property pointer, property is mandatory, property change request is fully handled by indigo_mount_change_property
 */
#define MOUNT_ALIGNMENT_MODE_PROPERTY									(MOUNT_CONTEXT->mount_alignment_mode_property)

/** MOUNT_ALIGNMENT_MODE.SINGLE_POINT property item pointer.
 */
#define MOUNT_ALIGNMENT_MODE_SINGLE_POINT_ITEM				(MOUNT_ALIGNMENT_MODE_PROPERTY->items+0)

/** MOUNT_ALIGNMENT_MODE.NEAREST_POINT property item pointer.
 */
#define MOUNT_ALIGNMENT_MODE_NEAREST_POINT_ITEM				(MOUNT_ALIGNMENT_MODE_PROPERTY->items+1)

/** MOUNT_ALIGNMENT_MODE.MULTI_POINT property item pointer.
 */
#define MOUNT_ALIGNMENT_MODE_MULTI_POINT_ITEM					(MOUNT_ALIGNMENT_MODE_PROPERTY->items+2)

/** MOUNT_ALIGNMENT_MODE.CONTROLLER property item pointer.
 */
#define MOUNT_ALIGNMENT_MODE_CONTROLLER_ITEM					(MOUNT_ALIGNMENT_MODE_PROPERTY->items+3)

//-----------------------------------------------
/** MOUNT_MAPED_COORDINATES property pointer, property is mandatory, read-only and should be fully controlled by device driver.
 */
#define MOUNT_RAW_COORDINATES_PROPERTY							(MOUNT_CONTEXT->mount_raw_coordinates_property)

/** MOUNT_RAW_COORDINATES.RA property item pointer.
 */
#define MOUNT_RAW_COORDINATES_RA_ITEM							(MOUNT_RAW_COORDINATES_PROPERTY->items+0)

/** MOUNT_EQUATORIAL_COORDINATES.DEC property item pointer.
 */
#define MOUNT_RAW_COORDINATES_DEC_ITEM							(MOUNT_RAW_COORDINATES_PROPERTY->items+1)

//------------------------------------------------
/** MOUNT_ALIGNMENT_SELECT_POINTS property pointer, property is not mandatory, property change request is fully handled by indigo_mount_change_property
 */
#define MOUNT_ALIGNMENT_SELECT_POINTS_PROPERTY				(MOUNT_CONTEXT->mount_alignment_select_points_property)

//------------------------------------------------
/** MOUNT_ALIGNMENT_DELETE_POINTS property pointer, property is not mandatory, property change request is fully handled by indigo_mount_change_property
 */
#define MOUNT_ALIGNMENT_DELETE_POINTS_PROPERTY				(MOUNT_CONTEXT->mount_alignment_delete_points_property)

//------------------------------------------------
/** MOUNT_ALIGNMENT_RESET property pointer, property is not mandatory, property change request is handled by indigo_mount_change_property
 */
#define MOUNT_ALIGNMENT_RESET_PROPERTY				(MOUNT_CONTEXT->mount_alignment_reset_property)

/** MOUNT_ALIGNMENT_RESET.RESET proeprty item pointer.
 */
#define MOUNT_ALIGNMENT_RESET_ITEM				    (MOUNT_CONTEXT->mount_alignment_reset_property->items+0)

//------------------------------------------------
/** MOUNT_EPOCH property pointer, property is optional
 */
#define MOUNT_EPOCH_PROPERTY													(MOUNT_CONTEXT->mount_epoch_property)

/** MOUNT_EPOCH.EPOCH property item pointer.
 */
#define MOUNT_EPOCH_ITEM															(MOUNT_EPOCH_PROPERTY->items+0)

//------------------------------------------------
/** MOUNT_SIDE_OF_PIER property pointer, property is optional
 */
#define MOUNT_SIDE_OF_PIER_PROPERTY										(MOUNT_CONTEXT->mount_side_of_pier_property)

/** MOUNT_SIDE_OF_PIER.EAST property item pointer.
 The side of the pier the OTA is on (ASCOM and INDI convention): EAST means the OTA is east of the pier pointing west,
 i.e. the normal (not flipped) pointing state for hour angle >= 0, WEST means the OTA is west of the pier pointing east.
 */
#define MOUNT_SIDE_OF_PIER_EAST_ITEM									(MOUNT_SIDE_OF_PIER_PROPERTY->items+0)

/** MOUNT_SIDE_OF_PIER.WEST property item pointer.
 */
#define MOUNT_SIDE_OF_PIER_WEST_ITEM									(MOUNT_SIDE_OF_PIER_PROPERTY->items+1)

//------------------------------------------------
/** MOUNT_PEC property pointer, property is optional.
 */
#define MOUNT_PEC_PROPERTY														(MOUNT_CONTEXT->mount_pec_property)
#define MOUNT_PEC_ENABLED_ITEM                				(MOUNT_PEC_PROPERTY->items+0)
#define MOUNT_PEC_DISABLED_ITEM               				(MOUNT_PEC_PROPERTY->items+1)
	
//------------------------------------------------
/** MOUNT_PEC_TRAINING property pointer, property is optional.
 */
#define MOUNT_PEC_TRAINING_PROPERTY										(MOUNT_CONTEXT->mount_pec_training_property)
#define MOUNT_PEC_TRAINIG_STARTED_ITEM           			(MOUNT_PEC_TRAINING_PROPERTY->items+0)
#define MOUNT_PEC_TRAINIG_STOPPED_ITEM           			(MOUNT_PEC_TRAINING_PROPERTY->items+1)


//------------------------------------------------
/** MOUNT_STATE property pointer, property is optional.
 */
#define MOUNT_STATE_PROPERTY													(MOUNT_CONTEXT->mount_state_property)
#define MOUNT_STATE_SLEW_ITEM													(MOUNT_STATE_PROPERTY->items+0)
#define MOUNT_STATE_PARK_ITEM													(MOUNT_STATE_PROPERTY->items+1)
#define MOUNT_STATE_HOME_ITEM													(MOUNT_STATE_PROPERTY->items+2)
#define MOUNT_STATE_TRACKING_ITEM											(MOUNT_STATE_PROPERTY->items+3)


//------------------------------------------------
/** Max number of alignment points.
 */

#define MOUNT_MAX_ALIGNMENT_POINTS										100

//------------------------------------------------
/** Definition of side of pier
 */

#define MOUNT_SIDE_EAST																0	///< OTA east of the pier, pointing west
#define MOUNT_SIDE_WEST																1	///< OTA west of the pier, pointing east

/** Aligment point structure.
 */

typedef struct {
	bool used;
	double lst;
	double ra, dec;						//  Where user says it is really pointing
	double raw_ra, raw_dec;		//  Where mount says it is pointing
	int side_of_pier;					//  East or West DEC slew?
} indigo_alignment_point;

//------------------------------------------------
/** Mount device context structure.
 */
typedef struct {
	indigo_device_context device_context;										///< device context base
	int alignment_point_count;															///< number of defined alignment points
	indigo_alignment_point alignment_points[MOUNT_MAX_ALIGNMENT_POINTS]; ///< alignment points
	indigo_property *mount_geographic_coordinates_property;	///< MOUNT_GEOGRAPHIC_COORDINATES property pointer
	indigo_property *mount_info_property;                   ///< MOUNT_INFO property pointer
	indigo_property *mount_lst_time_property;								///< MOUNT_LST_TIME property pointer
	indigo_property *mount_utc_time_property;               ///< MOUNT_UTC_TIME property_pointer
	indigo_property *mount_set_host_time_property;          ///< MOUNT_UTC_FROM_HOST property_pointer
	indigo_property *mount_park_property;										///< MOUNT_PARK property pointer
	indigo_property *mount_set_park_property;								///< MOUNT_PARK_SET property pointer
	indigo_property *mount_park_position_property;					///< MOUNT_PARK_POSITION property pointer
	indigo_property *mount_home_property;										///< MOUNT_HOME property pointer
	indigo_property *mount_set_home_property;								///< MOUNT_HOME_SET property pointer
	indigo_property *mount_home_position_property;					///< MOUNT_HOME_POSITION property pointer
	indigo_property *mount_on_coordinates_set_property;			///< MOUNT_ON_COORDINATES_SET property pointer
	indigo_property *mount_slew_rate_property;							///< MOUNT_SLEW_RATE property pointer
	indigo_property *mount_track_rate_property;							///< MOUNT_TRACK_RATE property pointer
	indigo_property *mount_custom_tracking_rate_property;		///< MOUNT_CUSTOM_TRACKING_RATE property pointer
	indigo_property *mount_tracking_property;								///< MOUNT_TRACKING property pointer
	indigo_property *mount_guide_rate_property;							///< MOUNT_GUIDE_RATE property pointer
	indigo_property *mount_equatorial_coordinates_property;	///< MOUNT_EQUATORIAL_COORDINATES property pointer
	indigo_property *mount_horizontal_coordinates_property;	///< MOUNT_HORIZONTAL_COORDINATES property pointer
	indigo_property *mount_abort_motion_property;						///< MOUNT_ABORT_MOTION property pointer
	indigo_property *mount_motion_dec_property;							///< MOUNT_MOTION_NS property pointer
	indigo_property *mount_motion_ra_property;							///< MOUNT_MOTION_WE property pointer
	indigo_property *mount_alignment_mode_property;					///< MOUNT_ALIGNMENT_MODE property pointer
	indigo_property *mount_raw_coordinates_property;				///< MOUNT_RAW_COORDINATES property pointer
	indigo_property *mount_alignment_select_points_property;///< MOUNT_ALIGNMENT_SELECT_POINTS property pointer
	indigo_property *mount_alignment_delete_points_property;///< MOUNT_ALIGNMENT_DELETE_POINTS property pointer
	indigo_property *mount_epoch_property;									///< MOUNT_EPOCH property pointer
	indigo_property *mount_side_of_pier_property;						///< MOUNT_SIDE_OF_PIER property pointer
	indigo_property *mount_pec_property;										///< MOUNT_PEC property pointer
	indigo_property *mount_pec_training_property;						///< MOUNT_PEC_TRAINING property pointer
	indigo_property *mount_alignment_reset_property;				///< MOUNT_ALIGNMENT_RESET property pointer
	indigo_property *mount_state_property;									///< MOUNT_STATE property pointer
	indigo_client_ref motion_dec_client;										///< attachment of the client that last requested MOUNT_MOTION_DEC, written in change_property() under the bus mutex, read only by the bus under its mutex
	indigo_client_ref motion_ra_client;											///< attachment of the client that last requested MOUNT_MOTION_RA, written in change_property() under the bus mutex, read only by the bus under its mutex
	time_t utc_target;																			///< UTC time of the last admitted MOUNT_UTC_TIME request, -1 if it was missing or unparsable, see indigo_mount_set_utc_target()
	int utc_offset_target;																	///< UTC offset in hours of the last admitted MOUNT_UTC_TIME request, see indigo_mount_set_utc_target()
} indigo_mount_context;

/** Attach callback function.
 */
INDIGO_EXTERN indigo_result indigo_mount_attach(indigo_device *device, const char* driver_name, unsigned version);
/** Enumerate properties callback function.
 */
INDIGO_EXTERN indigo_result indigo_mount_enumerate_properties(indigo_device *device, indigo_client *client, indigo_property *property);
/** Change property callback function.
 */
INDIGO_EXTERN indigo_result indigo_mount_change_property(indigo_device *device, indigo_client *client, indigo_property *property);
/** Detach callback function.
 */
INDIGO_EXTERN indigo_result indigo_mount_detach(indigo_device *device);

/** Record the client requesting manual motion, call it from the MOUNT_MOTION_DEC and MOUNT_MOTION_RA change branches
    of change_property() with the incoming request once it passed the driver's admission checks, just before its values
    are copied and processed. It records the reference of the client's current bus attachment (indigo_current_client_ref()),
    so the motion is not handed to another client attached at the same address if the requester detaches before the
    commit. A request without a client, or from a client no longer attached, records no client. Generated drivers call it
    automatically.
 */
INDIGO_EXTERN void indigo_mount_record_motion_client(indigo_device *device, indigo_client *client, indigo_property *property);

/** Commit the client recorded by indigo_mount_record_motion_client() as the owner of the manual motion of MOUNT_MOTION_DEC
    or MOUNT_MOTION_RA (property), call it from their change handlers after the driver started or stopped the motion. If
    an item is On and the property is not in ALERT state, the release of the motion (all items switched Off) is registered
    by indigo_register_detach_abort() to be sent if that client detaches, e.g. because its network connection was lost;
    if that attachment has already ended (or the request had no client), the release is sent at once through
    indigo_change_property(). Otherwise the motion is unregistered. Called with MOUNT_ABORT_MOTION_PROPERTY from the abort
    handler it unregisters both axes. It does not publish the property. The base class also unregisters both axes when
    the device disconnects or detaches. Generated drivers call it automatically.
 */
INDIGO_EXTERN void indigo_mount_commit_motion_client(indigo_device *device, indigo_property *property);

/** Record the time requested by a MOUNT_UTC_TIME change, call it from the MOUNT_UTC_TIME change branch of change_property()
    with the incoming request, before its values are copied and processed. A driver whose status poll refreshes
    MOUNT_UTC_ITEM and MOUNT_UTC_OFFSET_ITEM on the device queue cannot rely on the copied items: the poll's check of the
    BUSY state and its write are not atomic with the copy on the bus thread, so the requested time can be replaced by
    the mount clock before the handler reads it. The handler therefore sends the target recorded here (read it with
    indigo_mount_get_utc_target()) and writes it back into the items once the mount accepted it.
    The time and the offset are parsed from the request itself; a missing or unparsable time is recorded as -1, a
    missing offset keeps the current MOUNT_UTC_OFFSET_ITEM. The target is recorded only while MOUNT_UTC_TIME_PROPERTY is
    not BUSY, so a request the framework drops as BUSY does not replace the target of the handler it is waiting for.
 */
INDIGO_EXTERN void indigo_mount_set_utc_target(indigo_device *device, indigo_property *request);

/** Get the target recorded by indigo_mount_set_utc_target(), call it from the MOUNT_UTC_TIME change handler.
    Returns the requested UTC time, or -1 if the request carried no valid time; offset receives the UTC offset in hours.
 */
INDIGO_EXTERN time_t indigo_mount_get_utc_target(indigo_device *device, int *offset);

/** Translate coordinates to native.
 */

INDIGO_EXTERN indigo_result indigo_translated_to_raw(indigo_device *device, double ra, double dec, double *raw_ra, double *raw_dec);
INDIGO_EXTERN indigo_result indigo_translated_to_raw_with_lst(indigo_device *device, double lst, double ra, double dec, int side_of_pier, double *raw_ra, double *raw_dec);

/** Translate coordinates from native.
 */

INDIGO_EXTERN indigo_result indigo_raw_to_translated(indigo_device *device, double raw_ra, double raw_dec, double *ra, double *dec);
INDIGO_EXTERN indigo_result indigo_raw_to_translated_with_lst(indigo_device *device, double lst, double raw_ra, double raw_dec, int side_of_pier, double *ra, double *dec);

/** Get mount UTC if available otherwise return host UTC.
 */
INDIGO_EXTERN time_t indigo_get_mount_utc(indigo_device *device);

/** Translate coordinates from native.
 */

INDIGO_EXTERN void indigo_update_coordinates(indigo_device *device, const char *message);

/** Load alignment points.
 */

INDIGO_EXTERN void indigo_mount_load_alignment_points(indigo_device *device);

/** Save alignment points.
 */

INDIGO_EXTERN void indigo_mount_save_alignment_points(indigo_device *device);

/** Update alignment points.
 */

INDIGO_EXTERN void indigo_mount_update_alignment_points(indigo_device *device);

/** Pointing of a simulated mount shared with simulated cameras loaded into the same process.
 */
typedef struct {
	double ra;					///< raw (physical) RA in hours, in the epoch below
	double dec;					///< raw (physical) Dec in degrees, in the epoch below
	double epoch;				///< epoch of ra/dec, 0 = JNow
	double latitude;		///< site latitude in degrees
	double longitude;		///< site longitude in degrees
	bool west;					///< OTA is on the west side of the pier
	bool guidable;			///< mount follows guide pulses (it is neither parked nor slewing)
} indigo_simulated_mount_state;

/** Publish the pointing of a simulated mount, or withdraw it if state is NULL and device is the last publisher.
 Guide offsets requested by indigo_simulated_mount_guide() since the last call are added to state->ra and state->dec,
 the mount has to move its own position by the same amount.
 */
INDIGO_EXTERN void indigo_set_simulated_mount_state(indigo_device *device, indigo_simulated_mount_state *state);

/** Get the pointing of a simulated mount, return false if no simulated mount is connected.
 */
INDIGO_EXTERN bool indigo_get_simulated_mount_state(indigo_simulated_mount_state *state);

/** Move a simulated mount by ra hours and dec degrees, return true if a connected simulated mount accepted the request.
 Return false if no simulated mount is connected or the connected mount can not follow guide pulses.
 */
INDIGO_EXTERN bool indigo_simulated_mount_guide(double ra, double dec);

#ifdef __cplusplus
}
#endif

#endif /* indigo_mount_h */
