// Copyright (c) 2021-2026 Rumen G.Bogdanvski
// All rights reserved.
//
// You can use this software under the terms of 'INDIGO Astronomy
// open-source license' (see LICENSE.md).
//
// THIS SOFTWARE IS PROVIDED BY THE AUTHORS 'AS IS' AND ANY EXPRESS
// OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
// GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
// WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

// version history
// 2.0 by Rumen G. Bogdanovski <rumenastro@gmail.com>

#ifndef indigo_fits_h
#define indigo_fits_h

#if defined(INDIGO_WINDOWS)
#if defined(INDIGO_WINDOWS_DLL)
#define INDIGO_EXTERN __declspec(dllexport)
#else
#define INDIGO_EXTERN __declspec(dllimport)
#endif
#else
#define INDIGO_EXTERN extern
#endif

#ifdef __cplusplus
extern "C" {
#endif

#ifndef FITS_RECORD_SIZE
#define FITS_RECORD_SIZE 2880
#endif

typedef enum {
	INDIGO_FITS_NUMBER = 1,
	INDIGO_FITS_STRING,
	INDIGO_FITS_LOGICAL
} indigo_fits_keyword_type;

typedef struct {
	indigo_fits_keyword_type type;
	const char *name;
	union {
		double number;
		const char *string;
		bool logical;
	};
	const char *comment;
} indigo_fits_keyword;

/** Convert a complete RAW1/RAW2/RAW3/RAW6 image to record-aligned FITS.
 * Input and output allocations must be distinct. Metadata can span header records;
 * keyword names must fit eight characters and each formatted card must fit 80 bytes.
 * Invalid input or metadata returns INDIGO_FAILED with errno set, preserving the
 * existing output allocation and size, including on allocation failure.
 */
INDIGO_EXTERN indigo_result indigo_raw_to_fits(char *image, int in_size, char **fits, int *fits_size, indigo_fits_keyword *keywords);

#ifdef __cplusplus
}
#endif

#endif /* indigo_guider_utils_h */
