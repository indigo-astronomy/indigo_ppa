// Copyright (c) 2016-2026 CloudMakers, s. r. o.
// All rights reserved.
//
// You can use this software under the terms of 'INDIGO Astronomy
// open-source license' (see LICENSE.md).
//
// THIS SOFTWARE IS PROVIDED BY THE AUTHORS 'AS IS' AND ANY EXPRESS
// OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
// GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
// WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

// version history
// 2.0 by Peter Polakovic <peter.polakovic@cloudmakers.eu>

/** INDIGO Driver base
 \file indigo_driver.h
 */

#ifndef indigo_device_h
#define indigo_device_h
#include <stdint.h>
#include <pthread.h>
#include <indigo/indigo_bus.h>
#include <indigo/indigo_uni_io.h>
#include <indigo/indigo_names.h>
#include <indigo/indigo_timer.h>

#include <indigo/indigo_usbserial_utils.h>

#if defined(INDIGO_LINUX)
#include <malloc.h>
#define MALLOCED_SIZE malloc_usable_size
#elif defined(INDIGO_MACOS)
#include <malloc/malloc.h>
#define MALLOCED_SIZE malloc_size
#elif defined(INDIGO_WINDOWS)
#include <malloc.h>
#define MALLOCED_SIZE _msize
#endif

#ifndef UT2JD
#define DELTA_UT1_UTC (0.0299836 / 86400.0) /* For 2025-05-22 */
#define UT2JD(t)         ((t) / 86400.0 + 2440587.5 + DELTA_UT1_UTC)
#define JDNOW            UT2JD(time(NULL))
#endif

#if defined(INDIGO_WINDOWS)
#if defined(INDIGO_WINDOWS_DLL)
#define INDIGO_EXTERN __declspec(dllexport)
#else
#define INDIGO_EXTERN __declspec(dllimport)
#endif
#else
#define INDIGO_EXTERN extern
#endif

#ifdef __cplusplus
extern "C" {
#endif

/** Main group name string.
 */
#define MAIN_GROUP                    "Main"

/** Advanced group name string.
 */
#define ADVANCED_GROUP            		"Advanced"

/** Site group name string.
 */
#define SITE_GROUP            				"Site"

/** Device context pointer.
 */
#define DEVICE_CONTEXT                ((indigo_device_context *)device->device_context)

/** Master device context pointer.
 */
#define MASTER_DEVICE_CONTEXT                ((indigo_device_context *)device->master_device->device_context)

/** CONNECTION property pointer, property is mandatory, property change request handler should set property items and state and call indigo_device_change_property() on exit.
 */
#define CONNECTION_PROPERTY           (DEVICE_CONTEXT->connection_property)

/** CONNECTION.CONNECTED property item pointer.
 */
#define CONNECTION_CONNECTED_ITEM     (CONNECTION_PROPERTY->items+0)

/** CONNECTION.DISCONNECTED property item pointer.
 */
#define CONNECTION_DISCONNECTED_ITEM  (CONNECTION_PROPERTY->items+1)

/** INFO property pointer, property is mandatory.
 */
#define INFO_PROPERTY                 (DEVICE_CONTEXT->info_property)

/** INFO.DEVICE_NAME property item pointer.
 */
#define INFO_DEVICE_NAME_ITEM         (INFO_PROPERTY->items+0)

/** INFO.DEVICE_DRIVER  property item pointer.
 */
#define INFO_DEVICE_DRIVER_ITEM      (INFO_PROPERTY->items+1)

/** INFO.DEVICE_VERSION property item pointer.
 */
#define INFO_DEVICE_VERSION_ITEM      (INFO_PROPERTY->items+2)

/** INFO.DEVICE_INTERFACE property item pointer.
 */
#define INFO_DEVICE_INTERFACE_ITEM    (INFO_PROPERTY->items+3)

/** INFO.DEVICE_MODEL property item pointer.
 */
#define INFO_DEVICE_MODEL_ITEM         (INFO_PROPERTY->items+4)

/** INFO.DEVICE_FIRMWARE_REVISION property item pointer.
 */
#define INFO_DEVICE_FW_REVISION_ITEM   (INFO_PROPERTY->items+5)

/** INFO.DEVICE_HARDWARE_REVISION property item pointer.
 */
#define INFO_DEVICE_HW_REVISION_ITEM   (INFO_PROPERTY->items+6)

/** INFO.DEVICE_SERIAL_NUMBER property item pointer.
 */
#define INFO_DEVICE_SERIAL_NUM_ITEM    (INFO_PROPERTY->items+7)

/** INFO.FRAMEWORK_NAME property item pointer.
 */
#define INFO_FRAMEWORK_NAME_ITEM      (INFO_PROPERTY->items+3)

/** INFO.FRAMEWORK_VERSION property item pointer.
 */
#define INFO_FRAMEWORK_VERSION_ITEM   (INFO_PROPERTY->items+4)

/** SIMULATION property pointer, property is optional.
 */
#define SIMULATION_PROPERTY           (DEVICE_CONTEXT->simulation_property)

/** SIMULATION.DISABLED property item pointer.
 */
#define SIMULATION_ENABLED_ITEM       (SIMULATION_PROPERTY->items+0)

/** SIMULATION.DISABLED property item pointer.
 */
#define SIMULATION_DISABLED_ITEM      (SIMULATION_PROPERTY->items+1)

/** CONFIG property pointer, property is mandatory.
 */
#define CONFIG_PROPERTY               (DEVICE_CONTEXT->configuration_property)

/** CONFIG.SAVE property item pointer.
 */
#define CONFIG_SAVE_ITEM              (CONFIG_PROPERTY->items+0)

/** CONFIG.LOAD property item pointer.
 */
#define CONFIG_LOAD_ITEM              (CONFIG_PROPERTY->items+1)

/** CONFIG.DEFAULT property item pointer.
 */

#define CONFIG_REMOVE_ITEM           (CONFIG_PROPERTY->items+2)

/** Number of profiles
 */

#define PROFILE_COUNT									5

/** PROFILE_NAME property pointer, property is mandatory.
 */
#define PROFILE_NAME_PROPERTY         (DEVICE_CONTEXT->profile_name_property)

/** PROFILE_NAME.NAME_0 property item pointer.
 */
#define PROFILE_NAME_ITEM              (PROFILE_NAME_PROPERTY->items+0)

/** PROFILE property pointer, property is mandatory.
 */
#define PROFILE_PROPERTY               (DEVICE_CONTEXT->profile_property)

/** PROFILE.PROFILE_0 property item pointer.
 */
#define PROFILE_ITEM              		(PROFILE_PROPERTY->items+0)

/** DEVICE_PORT property pointer, property is optional, property change request is handled by indigo_device_change_property.
 */
#define DEVICE_PORT_PROPERTY					(DEVICE_CONTEXT->device_port_property)

/** DEVICE_PORT.DEVICE_PORT property item pointer.
 */
#define DEVICE_PORT_ITEM							(DEVICE_PORT_PROPERTY->items+0)

/** DEVICE_BAUDRATE property pointer, property is optional, property change request is handled by indigo_device_change_property.
 */
#define DEVICE_BAUDRATE_PROPERTY                                    (DEVICE_CONTEXT->device_baudrate_property)

/** DEVICE_BAUDRATE.BAUDRATE property item pointer.
 */
#define DEVICE_BAUDRATE_ITEM                                                        (DEVICE_BAUDRATE_PROPERTY->items+0)


/** DEVICE_PORTS property pointer, property is optional, property change request is handled by indigo_device_change_property.
 */
#define DEVICE_PORTS_PROPERTY					(DEVICE_CONTEXT->device_ports_property)

/** AUTHENTICATION property pointer, property is optional, property change request is handled by indigo_device_change_property.
 */
#define AUTHENTICATION_PROPERTY					(DEVICE_CONTEXT->device_auth_property)

/** AUTHENTICATION.PASSWORD property item pointer.
 */
#define AUTHENTICATION_PASSWORD_ITEM			(AUTHENTICATION_PROPERTY->items+0)

/** AUTHENTICATION.USER property item pointer.
 */
#define AUTHENTICATION_USER_ITEM					(AUTHENTICATION_PROPERTY->items+1)

/** Client name for saved configuration reader.
 */

/** ADDITIONAL_INSTANCES  property pointer, property is optional, property change request is handled by indigo_device_change_property.
 */
#define ADDITIONAL_INSTANCES_PROPERTY					(DEVICE_CONTEXT->device_inst_property)

/** ADDITIONAL_INSTANCES.COUNT property item pointer.
 */
#define ADDITIONAL_INSTANCES_COUNT_ITEM			(ADDITIONAL_INSTANCES_PROPERTY->items+0)


#define CONFIG_READER								"CONFIG_READER"
#define MAX_ADDITIONAL_INSTANCES		4

/** Device context structure.
 */

typedef struct {
	indigo_uni_handle *property_save_file_handle;            ///< handle for property save
	void *config_restore;                      ///< configuration restore observer and pending requests
	pthread_mutex_t config_mutex;							///< mutex for configuration load/save synchronisation
	pthread_mutex_t device_mutex;							///< mutex for synchronising multi-device access over single low level connection
	indigo_timer *timers;											///< active timer list
	indigo_queue *queue;											///< queue for handling property changes
	indigo_property *connection_property;     ///< CONNECTION property pointer
	indigo_property *info_property;           ///< INFO property pointer
	indigo_property *simulation_property;     ///< SIMULATION property pointer
	indigo_property *configuration_property;  ///< CONFIGURATION property pointer
	indigo_property *profile_name_property; 	///< PROFILE_NAME property pointer
	indigo_property *profile_property; 				///< PROFILE property pointer
	indigo_property *device_port_property;		///< DEVICE_PORT property pointer
	indigo_property *device_baudrate_property;///< DEVICE_BAUDRATE property pointer
	indigo_property *device_ports_property;		///< DEVICE_PORTS property pointer
	indigo_property *device_auth_property;		///< SECURITY property pointer
	indigo_property *device_inst_property;		///< ADDITIONAL_INSTANCES  property pointer
	indigo_device *additional_device_instances[MAX_ADDITIONAL_INSTANCES]; ///< additional device instances
} indigo_device_context;

/** log macros
*/

#define INDIGO_DRIVER_LOG(driver_name, ...) INDIGO_LOG(indigo_driver_log(INDIGO_LOG_INFO, driver_name, __FUNCTION__, __LINE__, ##__VA_ARGS__))
#define INDIGO_DRIVER_ERROR(driver_name, ...) INDIGO_ERROR(indigo_driver_log(INDIGO_LOG_ERROR, driver_name, __FUNCTION__, __LINE__, ##__VA_ARGS__))
#define INDIGO_DRIVER_DEBUG(driver_name, ...) INDIGO_DEBUG_DRIVER(indigo_driver_log(INDIGO_LOG_DEBUG, driver_name, __FUNCTION__, __LINE__, ##__VA_ARGS__))
#define INDIGO_DRIVER_TRACE(driver_name, ...) INDIGO_TRACE_DRIVER(indigo_driver_log(INDIGO_LOG_TRACE, driver_name, __FUNCTION__, __LINE__, ##__VA_ARGS__))

#define INDIGO_DEVICE_ATTACH_LOG(driver_name, device_name) INDIGO_DRIVER_LOG(driver_name, "'%s' attached", device_name)
#define INDIGO_DEVICE_DETACH_LOG(driver_name, device_name) INDIGO_DRIVER_LOG(driver_name, "'%s' detached", device_name)

 /** set driver info.
  */

#define SET_DRIVER_INFO(dinfo, ddescr, dname, dversion, dmulti, dstatus)\
{\
	if (dinfo) {\
		INDIGO_COPY_NAME(dinfo->description, ddescr);\
		INDIGO_COPY_NAME(dinfo->name, dname);\
		dinfo->version = dversion;\
		dinfo->multi_device_support = dmulti;\
		dinfo->status = dstatus;\
	}\
}

#define VERIFY_NOT_CONNECTED(dev)\
{\
	indigo_device *device = dev;\
	if (device) {\
		if (!IS_DISCONNECTED)\
			return INDIGO_BUSY;\
		for (int i = 0; i < MAX_ADDITIONAL_INSTANCES; i++) {\
			indigo_device *tmp = DEVICE_CONTEXT->additional_device_instances[i];\
			indigo_device *device = tmp;\
			if (device != NULL && !IS_DISCONNECTED)\
				return INDIGO_BUSY;\
		}\
		indigo_usleep(100000);\
	}\
}

/** Deprecated no-op, always returns INDIGO_OK. The file based global lock was keyed by device name, which is assigned per process and therefore neither stable for the same hardware nor unique across different hardware. Kept only for source compatibility with out-of-tree drivers; do not use in new code.
*/
INDIGO_EXTERN indigo_result indigo_try_global_lock(indigo_device *device);

/** Deprecated no-op, always returns INDIGO_OK. See indigo_try_global_lock().
*/
INDIGO_EXTERN indigo_result indigo_global_unlock(indigo_device *device);

/** Device is connected.
 */

#define IS_CONNECTED	(DEVICE_CONTEXT != NULL && CONNECTION_CONNECTED_ITEM->sw.value && CONNECTION_PROPERTY->state == INDIGO_OK_STATE)

/** Device is disconnected.
 */

#define IS_DISCONNECTED	((DEVICE_CONTEXT == NULL) || (DEVICE_CONTEXT != NULL && CONNECTION_DISCONNECTED_ITEM->sw.value && CONNECTION_PROPERTY->state != INDIGO_BUSY_STATE))

/** Attach callback function.
 */
INDIGO_EXTERN indigo_result indigo_device_attach(indigo_device *device, const char* driver_name, indigo_version version, int interface_mask);

/** Enumerate properties callback function.
 */
INDIGO_EXTERN indigo_result indigo_device_enumerate_properties(indigo_device *device, indigo_client *client, indigo_property *property);

/** Change property callback function.
 */
INDIGO_EXTERN indigo_result indigo_device_change_property(indigo_device *device, indigo_client *client, indigo_property *property);

/** Detach callback function.
 */
INDIGO_EXTERN indigo_result indigo_device_detach(indigo_device *device);

/** Open config file.
 */

INDIGO_EXTERN indigo_uni_handle *indigo_open_config_file(char *device_name, int profile, bool create, const char *suffix);

/** Load properties.
 */
INDIGO_EXTERN indigo_result indigo_load_properties(indigo_device *device, bool default_properties);

/** Save single property.
 */
INDIGO_EXTERN indigo_result indigo_save_property(indigo_device*device, indigo_uni_handle **file_handle, indigo_property *property);

/** Save items of a property.
 */
INDIGO_EXTERN indigo_result indigo_save_property_items(indigo_device*device, indigo_uni_handle *file_handle, indigo_property *property, const int count, const char **items);

/** Remove properties.
 */
INDIGO_EXTERN indigo_result indigo_remove_properties(indigo_device *device);

/** Start USB event handler thread.
 */
INDIGO_EXTERN void indigo_start_usb_event_handler(void);

/** Convert time_t to UTC ISO 8601 string.
 */
INDIGO_EXTERN void indigo_timetoisogm(time_t tstamp, char *isotime, int isotime_len);

/** Convert UTC ISO 8601 time string to time_t.
 */
INDIGO_EXTERN time_t indigo_isogmtotime(char *isotime);

/** Convert time_t to local time ISO 8601 string.
 */
INDIGO_EXTERN void indigo_timetoisolocal(time_t tstamp, char *isotime, int isotime_len);

/** Convert local time ISO 8601 string to time_t.
 */
INDIGO_EXTERN time_t indigo_isolocaltotime(char *isotime);

/** Get host UTC offset
 */

INDIGO_EXTERN int indigo_get_utc_offset(void);

/** Get host DST state
 */

INDIGO_EXTERN int indigo_get_dst_state(void);

/** Get host timezone state
 */

INDIGO_EXTERN long indigo_get_timezone(void);

/** Enumerate serial ports.
 */
INDIGO_EXTERN void indigo_enumerate_serial_ports(indigo_device *device, indigo_property *property);

/** Set the additional DEVICE_PORTS items of the driver of the device, e.g. network devices found by a driver specific discovery.
 They are shared by all devices of the driver, appended after the serial ports, kept when the serial ports change and replace the previous ones. Count 0 removes them.
 */
INDIGO_EXTERN void indigo_set_additional_ports(indigo_device *device, int count, const char **names, const char **labels);

/** Check for double connect/disconnect request.

    A valid connect request also resolves a device port of plain auto:// to the matching serial port,
    before the driver opens it.
 */
INDIGO_EXTERN bool indigo_ignore_connection_change(indigo_device *device, indigo_property *request);

/** Accept a CONNECTION change and run the handler on the device queue.

    A repeated request for the state the device is already in is ignored. Otherwise the requested
    values are taken, CONNECTION is published BUSY and only then is the handler queued: the handler
    runs on another thread and a connect that publishes BUSY after queuing lets it observe a state
    that is not there yet. Expects `device` and `property` in scope, like INDIGO_COPY_*_PROCESS_CHANGE.
 */
#define INDIGO_PROCESS_CONNECT(h) if (!indigo_ignore_connection_change(device, property)) { indigo_property_copy_values(CONNECTION_PROPERTY, property, false); INDIGO_UPDATE_PROPERTY_STATE(CONNECTION_PROPERTY, INDIGO_BUSY_STATE, NULL); indigo_execute_handler(device, h); }

/** Accept a CONNECTION change and run the handler on a per-driver queue.

    As INDIGO_PROCESS_CONNECT, for a driver that serialises SDK enumeration, attach, open and close
    across all its instances on its own queue `q` guarded by `m`.
 */
#define INDIGO_PROCESS_QUEUED_CONNECT(q, m, h) if (!indigo_ignore_connection_change(device, property)) { indigo_property_copy_values(CONNECTION_PROPERTY, property, false); INDIGO_UPDATE_PROPERTY_STATE(CONNECTION_PROPERTY, INDIGO_BUSY_STATE, NULL); indigo_queue_add(q, device, INDIGO_TASK_PRIORITY_NORMAL, 0, h, m); }

/** Calculate position corrected with a backlash
*/
INDIGO_EXTERN int indigo_compensate_backlash(int requested_position, int current_position, int backlash, bool *is_last_move_poitive);

/** Lock mutex on master device
 */
INDIGO_EXTERN void indigo_lock_master_device(indigo_device *device);

/** Unlock mutex on master device
 */
INDIGO_EXTERN void indigo_unlock_master_device(indigo_device *device);

/** Unlock mutex on device
 */
INDIGO_EXTERN void indigo_lock_device(indigo_device *device);

/** Unlock mutex on device
 */
INDIGO_EXTERN void indigo_unlock_device(indigo_device *device);

/** Execute timer using master device lock
 */
INDIGO_EXTERN void indigo_set_device_timer(indigo_device *device, double delay, indigo_timer_callback handler, indigo_timer **timer);

/** Execute property change handler ASAP on device queue
 */
INDIGO_EXTERN void indigo_execute_handler(indigo_device *device, indigo_timer_callback handler);

/** Execute property change handler ASAP on device queue
 */
INDIGO_EXTERN void indigo_execute_handler_with_data(indigo_device *device, indigo_timer_with_data_callback handler, void *data);

/** Execute property change handler ASAP on device queue with priority
 */
INDIGO_EXTERN void indigo_execute_priority_handler(indigo_device *device, int priority, indigo_timer_callback handler);

/** Execute property change handler on device queue ASAP with priority and data
 */
INDIGO_EXTERN void indigo_execute_priority_handler_with_data(indigo_device *device, int priority, indigo_timer_with_data_callback handler, void *data);

/** Execute property change handler on device queue with specified delay
 */
INDIGO_EXTERN void indigo_execute_handler_in(indigo_device *device, double delay, indigo_timer_callback handler);

/** Execute property change handler on device queue with specified delay and data
 */
INDIGO_EXTERN void indigo_execute_handler_with_data_in(indigo_device *device, double delay, indigo_timer_with_data_callback handler, void *data);

/** Execute property change handler on device queue with specified delay and priority
 */
INDIGO_EXTERN void indigo_execute_priority_handler_in(indigo_device *device, int priority, double delay, indigo_timer_callback handler);

/** Execute property change handler on device queue with specified delay, priority and data
 */
INDIGO_EXTERN void indigo_execute_priority_handler_with_data_in(indigo_device *device, int priority, double delay, indigo_timer_with_data_callback handler, void *data);

/** Empty handler queue
 */
INDIGO_EXTERN void indigo_cancel_pending_handlers(indigo_device *device);

/** Remove scheduled handler from queue
 */
INDIGO_EXTERN void indigo_cancel_pending_handler(indigo_device *device, indigo_timer_callback callback);

/** Keep the shared library containing the given address loaded for the lifetime of the process.
    A vendor SDK that leaves a thread of its own running after its documented shutdown call makes
    that thread execute unmapped code once the driver is unloaded, which no driver can prevent by
    sequencing. Pinning the SDK library from the driver's initialization keeps its code mapped.
    Pass the address of an SDK function, for example indigo_pin_library((void *)SDKShutdown).
 */
INDIGO_EXTERN bool indigo_pin_library(const void *address);

#ifdef __cplusplus
}
#endif

#endif /* indigo_device_h */
